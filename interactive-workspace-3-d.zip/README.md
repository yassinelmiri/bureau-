# 3D Interactive Workspace Manager

A modern, interactive 3D workspace management system built with React, Three.js, and Next.js. Features bilingual support (English/French), real-time 3D visualization, and comprehensive admin controls.

## Features

### 3D Workspace Visualization
- **Interactive 3D Scene**: Explore your workspace in full 3D with mouse controls
- **Desk Management**: Click desks to view employee information and status
- **Room Exploration**: Interactive kitchen, meeting rooms, and restroom modules
- **Real-time Updates**: See status changes instantly reflected in the 3D space

### Employee Management
- View employee details: name, email, desk assignment
- Track employee status: Available, Occupied, Out of Service
- Admin controls to add, edit, or remove employees
- Assign employees to specific desks

### Room Modules

**Kitchen**
- Manage inventory items (coffee, tea, napkins, cleaning supplies, etc.)
- Track quantities for each item
- Add or remove items dynamically
- Admin-only inventory management

**Restroom**
- Monitor status: Available, Occupied, Cleaning
- Update status in real-time
- Visual status indicators

**Meeting Rooms**
- Track availability
- Quick status updates for scheduling

### Admin Dashboard
- Comprehensive control panel with three main sections:
  - **Employees**: Add, edit, remove employees; assign to desks
  - **Rooms**: Manage room statuses and configurations
  - **Kitchen**: Manage inventory and track supplies

### Bilingual Support
- Full English/French interface
- Toggle between languages with one click
- All labels, buttons, and messages translated
- Persistent language selection

### 3D Controls
- **Orbit Controls**: Rotate, zoom, and pan the camera
- **Click Interaction**: Click desks and rooms to view details
- **Status Indicators**: Color-coded visual feedback (blue=available, red=occupied, gray=out)
- **Hover Effects**: Visual feedback on interactive elements

## Getting Started

### Installation

1. Clone or download the project
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Run the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

4. Open [http://localhost:3000](http://localhost:3000) in your browser

### Usage

**For Regular Users:**
1. Navigate the 3D workspace using your mouse
2. Click desks to view employee information
3. Click rooms to see status and details
4. Use language buttons to switch between English/French

**For Administrators:**
1. Click the "Admin Panel" button in the header
2. Switch between tabs: Employees, Rooms, Kitchen
3. Add, edit, or remove items as needed
4. Changes are reflected in real-time in the 3D workspace

## Architecture

### Context-based State Management
- **LanguageContext**: Handles language switching and translations
- **WorkspaceContext**: Manages all workspace data (desks, employees, rooms, kitchen items)
- **AuthContext**: Manages admin authentication

### 3D Components
- **WorkspaceScene**: Main 3D canvas with lighting and controls
- **DeskModel**: 3D desk representation with status indicators
- **RoomModel**: 3D room representations
- **WorkspaceFloor**: Floor and walls layout

### UI Components
- **HeaderBar**: Navigation and language/admin controls
- **DeskPanel**: Detailed desk information and controls
- **RoomPanel**: Room status and details
- **AdminDashboard**: Admin control center

## Technologies

- **Next.js 16**: React framework with App Router
- **React Three Fiber**: 3D graphics with Three.js
- **Three.js**: 3D graphics library
- **Tailwind CSS**: Utility-first CSS framework
- **TypeScript**: Type-safe development
- **shadcn/ui**: High-quality UI components

## Color Scheme

- **Primary Blue**: #0055ff (interactive elements, highlights)
- **White**: #ffffff (backgrounds, cards)
- **Gray**: #333333 - #f0f0f0 (neutral elements)
- **Status Colors**:
  - Available: #0055ff (Blue)
  - Occupied: #ff6b6b (Red)
  - Out of Service: #999999 (Gray)

## Customization

### Adding More Desks
Modify the initial desk count in `context/workspace-context.tsx`:
\`\`\`tsx
const initialDesks: Desk[] = Array.from({ length: 20 }, (_, i) => ({
  // ... existing code
}));
\`\`\`

### Adding New Rooms
Update the `initialRooms` array in `context/workspace-context.tsx` with new room configurations.

### Translations
Add new translation keys to the `translations` object in `context/language-context.tsx`.

## Performance Tips

- Use admin mode sparingly for large workspaces
- Close panels when not in use to improve 3D interaction smoothness
- Zoom in/out carefully with large desk counts

## Browser Support

- Chrome/Chromium: Full support
- Firefox: Full support
- Safari: Full support
- Edge: Full support

## Future Enhancements

- Database integration for persistence
- Real-time multi-user updates
- Advanced analytics and reporting
- Custom workspace layouts
- Photo uploads for employees
- Meeting room booking system
